# VideoFinder — prototipe Android

Prototipe aplikasi Android sederhana untuk mengetik kata kunci (default: `swap wife`) lalu meneruskan pencarian ke Bing, DuckDuckGo, atau Google. Tidak bergantung pada PornMD.

## Yang sudah ada
- Antarmuka Android dengan kolom kata kunci.
- Konfirmasi usia 18+ saat aplikasi dibuka dan checkbox sebelum pencarian.
- Tombol untuk tiga mesin pencari web.
- Tidak mengunduh, menyimpan, atau meng-host video.

## Batasan penting
Ini **bukan APK siap pasang** dan bukan indeks video mandiri. Prototipe membuka browser ke mesin pencari; hasil pencarian dan penyaringan konten ditentukan oleh masing-masing penyedia. Beberapa mesin pencari dapat membatasi hasil dewasa. Jangan gunakan untuk mencari atau mengakses konten ilegal, nonkonsensual, atau yang melibatkan anak di bawah umur.

## Membuat APK dengan Android Studio
1. Instal Android Studio versi terbaru dan komponen Android SDK.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `VideoFinder`.
4. Tunggu **Gradle Sync** selesai. Jika diminta, izinkan Android Studio mengunduh Android Gradle Plugin/SDK yang diperlukan.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke ponsel Android dan instal. Android mungkin meminta izin instalasi dari sumber tersebut.

## Struktur
- `settings.gradle.kts`
- `build.gradle.kts`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/example/videofinder/MainActivity.kt`

Proyek ini memakai Kotlin dan Android UI bawaan tanpa library tambahan. Android Studio dan Gradle diperlukan untuk menghasilkan APK.
