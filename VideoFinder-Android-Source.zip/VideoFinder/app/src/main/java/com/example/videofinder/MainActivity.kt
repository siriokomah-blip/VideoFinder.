
package com.example.videofinder

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val APP_PASSWORD = "r0y5@t@n1c"
        private const val RESULTS_PER_PAGE = 50
    }

    private lateinit var queryInput: EditText
    private lateinit var resultsBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var searchButton: Button
    private lateinit var paginationBox: LinearLayout

    private val executor = Executors.newSingleThreadExecutor()

    private var currentQuery = ""
    private var currentPage = 1
    private var isLoading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPasswordScreen()
    }

    private fun showPasswordScreen() {
        val passwordInput = EditText(this).apply {
            hint = "Masukkan password"
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("VideoFinder")
            .setMessage("Masukkan password untuk melanjutkan")
            .setView(passwordInput)
            .setPositiveButton("Masuk", null)
            .setNegativeButton("Keluar") { _, _ -> finish() }
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener {
                    if (passwordInput.text.toString() == APP_PASSWORD) {
                        dialog.dismiss()
                        buildUi()
                    } else {
                        passwordInput.text.clear()
                        passwordInput.error = "Password salah"
                    }
                }
        }

        dialog.show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            setBackgroundColor(Color.rgb(16, 19, 25))
        }

        val title = TextView(this).apply {
            text = "VideoFinder"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Cari video dari berbagai situs"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        queryInput = EditText(this).apply {
            hint = "Masukkan kata kunci"
            setSingleLine(true)
            setTextSize(16f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(queryInput, matchWrap())

        searchButton = Button(this).apply {
            text = "Cari Video"
            isAllCaps = false
            setOnClickListener { searchVideos() }
        }
        root.addView(searchButton, matchWrap())

        statusText = TextView(this).apply {
            text = "Masukkan kata kunci untuk mencari."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultsBox)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        )

        val paginationScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }

        paginationBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }

        paginationScroll.addView(paginationBox)
        root.addView(paginationScroll, matchWrap())

        setContentView(root)
    }

    private fun searchVideos() {
        val query = queryInput.text.toString().trim()

        if (query.isBlank()) {
            queryInput.error = "Masukkan kata kunci"
            return
        }

        currentQuery = query
        currentPage = 1
        loadPage(1)
    }

    private fun loadPage(page: Int) {
        if (isLoading || page < 1 || currentQuery.isBlank()) return

        isLoading = true
        searchButton.isEnabled = false
        resultsBox.removeAllViews()
        statusText.text = "Memuat halaman $page..."
        updatePagination()

        val encoded = URLEncoder.encode(currentQuery, "UTF-8")
        val apiUrl =
            "https://www.eporner.com/api/v2/video/search/" +
            "?query=$encoded&per_page=$RESULTS_PER_PAGE" +
            "&page=$page&thumbsize=big&format=json"

        executor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(apiUrl).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 15000
                connection.readTimeout = 20000
                connection.setRequestProperty("Accept", "application/json")

                val response = connection.inputStream.bufferedReader().use {
                    it.readText()
                }

                val json = JSONObject(response)
                val videos = json.optJSONArray("videos")

                runOnUiThread {
                    if (isFinishing) return@runOnUiThread

                    resultsBox.removeAllViews()

                    if (videos == null || videos.length() == 0) {
                        statusText.text = "Tidak ada hasil di halaman $page."
                    } else {
                        currentPage = page
                        statusText.text =
                            "Eporner • Halaman $page • ${videos.length()} video"

                        for (i in 0 until videos.length()) {
                            addVideoResult(videos.getJSONObject(i))
                        }
                    }

                    updatePagination()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (isFinishing) return@runOnUiThread

                    statusText.text =
                        "Gagal memuat halaman. Periksa internet."
                    Toast.makeText(
                        this@MainActivity,
                        "Pencarian gagal.",
                        Toast.LENGTH_SHORT
                    ).show()

                    updatePagination()
                }
            } finally {
                connection?.disconnect()

                runOnUiThread {
                    isLoading = false
                    if (!isFinishing) searchButton.isEnabled = true
                    updatePagination()
                }
            }
        }
    }

    private fun updatePagination() {
        if (!::paginationBox.isInitialized) return

        paginationBox.removeAllViews()

        if (currentQuery.isBlank()) return

        if (currentPage > 1) {
            addPageButton("‹") {
                loadPage(currentPage - 1)
            }
        }

        val firstPage = maxOf(1, currentPage - 2)
        val lastPage = currentPage + 3

        for (page in firstPage..lastPage) {
            addPageButton(page.toString(), page == currentPage) {
                loadPage(page)
            }
        }

        addPageButton("›") {
            loadPage(currentPage + 1)
        }
    }

    private fun addPageButton(
        label: String,
        selected: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            minWidth = dp(42)
            setPadding(dp(4), 0, dp(4), 0)
            setTextColor(if (selected) Color.WHITE else Color.LTGRAY)
            setBackgroundColor(
                if (selected) Color.rgb(35, 110, 210)
                else Color.rgb(40, 46, 58)
            )
            isEnabled = !isLoading
            setOnClickListener { action() }
        }

        val params = LinearLayout.LayoutParams(
            dp(48), dp(44)
        )
        params.setMargins(dp(2), 0, dp(2), 0)
        paginationBox.addView(button, params)
    }

    private fun addVideoResult(video: JSONObject) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(29, 34, 43))
        }

        val thumbUrl = video.optJSONObject("default_thumb")
            ?.optString("src", "") ?: ""

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.DKGRAY)
        }
        card.addView(image, LinearLayout.LayoutParams(dp(120), dp(82)))

        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }

        val videoTitle = TextView(this).apply {
            text = video.optString("title", "Video tanpa judul")
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        textColumn.addView(videoTitle)

        val source = TextView(this).apply {
            text = "Sumber: Eporner"
            textSize = 12f
            setTextColor(Color.rgb(160, 190, 220))
            setPadding(0, dp(6), 0, 0)
        }
        textColumn.addView(source)

        val duration = TextView(this).apply {
            text = video.optString("length_min", "")
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        textColumn.addView(duration)

        card.addView(
            textColumn,
            LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        )

        val videoUrl = video.optString("url", "")
        card.setOnClickListener {
            if (videoUrl.startsWith("https://www.eporner.com/")) {
                try {
                    startActivity(
                        android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            Uri.parse(videoUrl)
                        )
                    )
                } catch (_: Exception) {
                    Toast.makeText(
                        this, "Tidak bisa membuka tautan.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(8)
        resultsBox.addView(card, params)

        if (thumbUrl.startsWith("https://")) {
            executor.execute {
                try {
                    val bitmap = URL(thumbUrl).openStream().use {
                        BitmapFactory.decodeStream(it)
                    }

                    if (bitmap != null) {
                        runOnUiThread {
                            if (!isFinishing) image.setImageBitmap(bitmap)
                        }
                    }
                } catch (_: Exception) {
                    // Thumbnail gagal dimuat.
                }
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
