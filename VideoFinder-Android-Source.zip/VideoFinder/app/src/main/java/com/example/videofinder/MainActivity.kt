
package com.example.videofinder

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Collections
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val APP_PASSWORD = "r0y5@t@n1c"
        private const val RESULTS_PER_PAGE = 20
        private const val TAG = "VideoFinder"
    }

    data class VideoResult(
        val title: String,
        val url: String,
        val thumbnail: String,
        val duration: String,
        val source: String
    )

    private lateinit var queryInput: EditText
    private lateinit var resultsBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var searchButton: Button
    private lateinit var paginationBox: LinearLayout

    private val executor = Executors.newSingleThreadExecutor()
    private val imageExecutor = Executors.newFixedThreadPool(3)

    private val thumbnailErrors =
        Collections.synchronizedList(mutableListOf<String>())

    private var currentQuery = ""
    private var currentPage = 1
    private var isLoading = false
    private var searchGeneration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPasswordScreen()
    }

    private fun showPasswordScreen() {
        val passwordInput = EditText(this).apply {
            hint = "Masukkan password"
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("VideoFinder")
            .setMessage("Masukkan password untuk melanjutkan")
            .setView(passwordInput)
            .setPositiveButton("Masuk", null)
            .setNegativeButton("Keluar") { _, _ -> finish() }
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener {
                    if (passwordInput.text.toString() == APP_PASSWORD) {
                        dialog.dismiss()
                        buildUi()
                    } else {
                        passwordInput.text.clear()
                        passwordInput.error = "Password salah"
                    }
                }
        }

        dialog.show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            setBackgroundColor(Color.rgb(16, 19, 25))
        }

        val title = TextView(this).apply {
            text = "VideoFinder"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Cari video dari 4 situs"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        queryInput = EditText(this).apply {
            hint = "Masukkan kata kunci"
            setSingleLine(true)
            setTextSize(16f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(queryInput, matchWrap())

        searchButton = Button(this).apply {
            text = "Cari Video"
            isAllCaps = false
            setOnClickListener { searchVideos() }
        }
        root.addView(searchButton, matchWrap())

        statusText = TextView(this).apply {
            text = "Masukkan kata kunci untuk mencari."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(8))
            setOnClickListener { showThumbnailErrors() }
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultsBox)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        )

        val paginationScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }

        paginationBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }

        paginationScroll.addView(paginationBox)
        root.addView(paginationScroll, matchWrap())

        val errorButton = Button(this).apply {
            text = "Lihat Error Thumbnail"
            isAllCaps = false
            setOnClickListener { showThumbnailErrors() }
        }
        root.addView(errorButton, matchWrap())

        setContentView(root)
    }

    private fun searchVideos() {
        val query = queryInput.text.toString().trim()

        if (query.isBlank()) {
            queryInput.error = "Masukkan kata kunci"
            return
        }

        currentQuery = query
        currentPage = 1
        searchGeneration++
        isLoading = false
        thumbnailErrors.clear()
        loadPage(1)
    }

    private fun loadPage(page: Int) {
        if (isLoading || page < 1 || currentQuery.isBlank()) return

        isLoading = true
        val generation = searchGeneration
        val query = currentQuery

        searchButton.isEnabled = false
        resultsBox.removeAllViews()
        statusText.text = "Mencari di 4 situs, halaman $page..."
        updatePagination()

        executor.execute {
            val allResults = mutableListOf<VideoResult>()
            val errors = mutableListOf<String>()

            try {
                allResults.addAll(searchEporner(query, page))
            } catch (e: Exception) {
                errors.add("Eporner: ${errorDescription(e)}")
                android.util.Log.e(TAG, "Eporner gagal", e)
            }

            try {
                allResults.addAll(
                    searchHtmlSite(
                        "xHamster",
                        "https://xhamster.com/search/" +
                            pathEncode(query) + "?page=$page",
                        query
                    )
                )
            } catch (e: Exception) {
                errors.add("xHamster: ${errorDescription(e)}")
                android.util.Log.e(TAG, "xHamster gagal", e)
            }

                        try {
                allResults.addAll(
                    searchHtmlSite(
                        "MyLust",
                        "https://mylust.com/search/?q=" +
                            urlEncode(query),
                        query
                    )
                )
            } catch (e: Exception) {
                errors.add("MyLust: ${errorDescription(e)}")
                android.util.Log.e(TAG, "MyLust gagal", e)
            }

            try {
                allResults.addAll(
                    searchHtmlSite(
                        "PornoXO",
                        "https://www.pornoxo.com/search/?q=" +
                            urlEncode(query),
                        query
                    )
                )
            } catch (e: Exception) {
                errors.add("PornoXO: ${errorDescription(e)}")
                android.util.Log.e(TAG, "PornoXO gagal", e)
            }

            runOnUiThread {
                if (isFinishing || generation != searchGeneration) {
                    return@runOnUiThread
                }

                resultsBox.removeAllViews()
                currentPage = page

                if (allResults.isEmpty()) {
                    statusText.text =
                        "Tidak ada hasil yang berhasil dibaca.\n" +
                        errors.joinToString("\n")
                } else {
                    statusText.text =
                        "Halaman $page • ${allResults.size} hasil" +
                        if (errors.isNotEmpty()) {
                            "\nSumber gagal: ${errors.joinToString()}"
                        } else {
                            ""
                        }

                    allResults.forEach { addVideoResult(it) }
                }

                isLoading = false
                searchButton.isEnabled = true
                updatePagination()
            }
        }
    }

    private fun searchEporner(
        query: String,
        page: Int
    ): List<VideoResult> {
        val apiUrl =
            "https://www.eporner.com/api/v2/video/search/" +
                "?query=${urlEncode(query)}" +
                "&per_page=$RESULTS_PER_PAGE" +
                "&page=$page&thumbsize=big&format=json"

        val json = JSONObject(fetchText(apiUrl))
        val videos = json.optJSONArray("videos") ?: return emptyList()
        val results = mutableListOf<VideoResult>()

        for (i in 0 until videos.length()) {
            val video = videos.optJSONObject(i) ?: continue
            val videoUrl = video.optString("url", "")

            if (!videoUrl.startsWith("https://www.eporner.com/")) {
                continue
            }

            val thumb = video.optJSONObject("default_thumb")
                ?.optString("src", "") ?: ""

            results.add(
                VideoResult(
                    title = cleanText(
                        video.optString("title", "Video tanpa judul")
                    ),
                    url = videoUrl,
                    thumbnail = normalizeImageUrl(
                        "Eporner", thumb
                    ),
                    duration = video.optString("length_min", ""),
                    source = "Eporner"
                )
            )
        }

        return results
    }

    private fun searchHtmlSite(
        site: String,
        searchUrl: String,
        query: String
    ): List<VideoResult> {
        val html = fetchText(searchUrl)

        android.util.Log.d(
            TAG,
            "$site | HTML length=${html.length} | URL=$searchUrl"
        )

        val results = parseVideoHtml(site, html, query)

        android.util.Log.d(
            TAG,
            "$site | hasil=${results.size} | thumbnail=" +
                results.count { it.thumbnail.isNotBlank() }
        )

        return results
    }

    private fun parseVideoHtml(
        site: String,
        html: String,
        query: String
    ): List<VideoResult> {
        val results = mutableListOf<VideoResult>()
        val seen = mutableSetOf<String>()

        val anchorRegex = Regex(
            """<a\b([^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*)>(.*?)</a\s*>""",
            setOf(
                RegexOption.IGNORE_CASE,
                RegexOption.DOT_MATCHES_ALL
            )
        )

        for (match in anchorRegex.findAll(html)) {
            if (results.size >= RESULTS_PER_PAGE) break

            val attrs = match.groupValues[1]
            val href = decodeEntities(match.groupValues[2])
            val inner = match.groupValues[3]

            val videoUrl = resolveUrl(site, href) ?: continue
            if (!isVideoPath(site, videoUrl)) continue
            if (!seen.add(videoUrl)) continue

            val titleFromLink = extractAttribute(attrs, "title")
            val titleFromAria = extractAttribute(attrs, "aria-label")

            val imageTag = Regex(
                """<img\b[^>]*>""",
                setOf(
                    RegexOption.IGNORE_CASE,
                    RegexOption.DOT_MATCHES_ALL
                )
            ).find(inner)?.value ?: ""

            val titleFromImage = extractAttribute(imageTag, "alt")

            val title = listOf(
                titleFromLink,
                titleFromAria,
                titleFromImage
            ).map { cleanText(it) }.firstOrNull {
                it.length >= 3 &&
                    !it.matches(Regex("""[\d\s.:xX-]+""")) &&
                    !it.matches(
                        Regex("""\d+\s*dp""", RegexOption.IGNORE_CASE)
                    )
            } ?: continue

            // Prioritaskan gambar yang berada di tautan video.
            var thumbnail = extractThumbnail(inner)

            // Fallback terbatas: periksa konteks dekat tautan.
            // Gambar fallback tetap perlu diverifikasi saat diuji.
            if (thumbnail.isBlank()) {
                val start = maxOf(0, match.range.first - 300)
                val end = minOf(html.length, match.range.last + 700)
                thumbnail = extractThumbnail(
                    html.substring(start, end)
                )
            }

            thumbnail = normalizeImageUrl(site, thumbnail)

            val duration = Regex(
                """\b\d{1,2}:\d{2}(?::\d{2})?\b"""
            ).find(inner)?.value ?: ""

            results.add(
                VideoResult(
                    title = title,
                    url = videoUrl,
                    thumbnail = thumbnail,
                    duration = duration,
                    source = site
                )
            )
        }

        return results
    }
   
    private fun extractThumbnail(html: String): String {
        val imageTag = Regex(
            """<(?:img|source)\b[^>]*>""",
            setOf(
                RegexOption.IGNORE_CASE,
                RegexOption.DOT_MATCHES_ALL
            )
        ).findAll(html).firstOrNull { tagMatch ->
            val tag = tagMatch.value
            val candidates = listOf(
                "data-src",
                "data-original",
                "data-lazy-src",
                "data-thumb",
                "data-thumbnail",
                "data-preview",
                "data-image",
                "poster",
                "src"
            )

            candidates.any { attr ->
                val value = extractAttribute(tag, attr)
                isCandidateImage(value) &&
                    !value.contains(".mp4", ignoreCase = true)
            }
        }?.value

        if (imageTag != null) {
            val attributes = listOf(
                "data-src",
                "data-original",
                "data-lazy-src",
                "data-thumb",
                "data-thumbnail",
                "data-preview",
                "data-image",
                "poster",
                "src"
            )

            for (attribute in attributes) {
                val value = extractAttribute(imageTag, attribute)
                if (
                    isCandidateImage(value) &&
                    !value.contains(".mp4", ignoreCase = true)
                ) {
                    return value
                }
            }

            val srcset = extractAttribute(imageTag, "srcset")
            if (srcset.isNotBlank()) {
                val candidates = srcset.split(",")
                for (candidate in candidates) {
                    val value = candidate.trim().substringBefore(" ")
                    if (
                        isCandidateImage(value) &&
                        !value.contains(".mp4", ignoreCase = true)
                    ) {
                        return value
                    }
                }
            }
        }

        val backgroundRegex = Regex(
            """(?i)background-image\s*:\s*url\(["']?([^)"']+)"""
        )

        for (match in backgroundRegex.findAll(html)) {
            val value = match.groupValues[1].trim()
            if (
                isCandidateImage(value) &&
                !value.contains(".mp4", ignoreCase = true)
            ) {
                return value
            }
        }

        return ""
    }

    private fun isCandidateImage(value: String): Boolean {
        val v = decodeEntities(value.trim())
        return (v.startsWith("https://") ||
            v.startsWith("http://") ||
            v.startsWith("//") ||
            v.startsWith("/")) &&
            !v.contains(".svg", ignoreCase = true) &&
            !v.startsWith("data:", ignoreCase = true)
    }

    private fun normalizeImageUrl(
        site: String,
        value: String
    ): String {
        val raw = decodeEntities(value.trim())
        if (!isCandidateImage(raw)) return ""

        return try {
            val absolute = URL(URL(siteOrigin(site) + "/"), raw)
            if (absolute.protocol != "https") "" else absolute.toString()
        } catch (_: Exception) {
            ""
        }
    }

    private fun isVideoPath(site: String, url: String): Boolean {
        val path = try {
            URL(url).path.lowercase()
        } catch (_: Exception) {
            return false
        }

        return when (site) {
            "xHamster" -> path.startsWith("/videos/")
            "MyLust" -> path.contains("/video") ||
                path.contains("/videos/") ||
                path.contains("/movie/")
            "PornoXO" -> path.contains("/video") ||
                path.contains("/videos/") ||
                path.contains("/movie/")
            else -> false
        }
    }

    private fun siteOrigin(site: String): String {
        return when (site) {
            "xHamster" -> "https://xhamster.com"
            "MyLust" -> "https://mylust.com"
            "PornoXO" -> "https://www.pornoxo.com"
            else -> "https://www.eporner.com"
        }
    }

    private fun fetchText(address: String): String {
        var connection: HttpURLConnection? = null

        try {
            connection =
                URL(address).openConnection() as HttpURLConnection

            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.instanceFollowRedirects = true

            connection.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            connection.setRequestProperty(
                "Accept",
                "text/html,application/json,*/*"
            )
            connection.setRequestProperty(
                "Accept-Language",
                "en-US,en;q=0.9"
            )

            val code = connection.responseCode
            if (code !in 200..299) {
                throw java.io.IOException("HTTP $code")
            }

            return connection.inputStream.bufferedReader(
                Charsets.UTF_8
            ).use { it.readText() }
        } finally {
            connection?.disconnect()
        }
    }

    private fun loadThumbnail(
        video: VideoResult,
        image: ImageView,
        generation: Int
    ) {
        if (video.thumbnail.isBlank()) {
            recordThumbnailError(
                "${video.source}: URL thumbnail tidak ditemukan | ${video.url}"
            )
            return
        }

        imageExecutor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection =
                    URL(video.thumbnail).openConnection() as HttpURLConnection

                connection.connectTimeout = 10000
                connection.readTimeout = 15000
                connection.instanceFollowRedirects = true

                connection.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                )
                connection.setRequestProperty(
                    "Referer",
                    siteOrigin(video.source) + "/"
                )
                connection.setRequestProperty(
    "Accept",
    "image/jpeg,image/png,image/webp,*/*;q=0.5"
)

                val code = connection.responseCode
                val contentType =
                    connection.contentType ?: "unknown"

                if (code !in 200..299) {
                    throw java.io.IOException(
                        "HTTP $code | type=$contentType"
                    )
                }

                if (!contentType.startsWith("image/")) {
                    throw java.io.IOException(
                        "Respons bukan gambar | HTTP $code | type=$contentType"
                    )
                }

                val bytes = connection.inputStream.use {
    it.readBytes()
}

val bitmapOptions = BitmapFactory.Options().apply {
    inJustDecodeBounds = true
}

BitmapFactory.decodeByteArray(
    bytes, 0, bytes.size, bitmapOptions
)

if (bytes.isEmpty()) {
    throw java.io.IOException("Respons gambar kosong")
}

if (bitmapOptions.outWidth <= 0 ||
    bitmapOptions.outHeight <= 0
) {
    val preview = String(bytes, 0, minOf(bytes.size, 120))
        .replace("\n", " ")
        .replace("\r", " ")

    throw java.io.IOException(
        "Bukan gambar yang dikenali Android; " +
        "ukuran=${bytes.size} byte; " +
        "type=${connection.contentType}; " +
        "awal respons=$preview"
    )
}

val bitmap = BitmapFactory.decodeByteArray(
    bytes, 0, bytes.size
) ?: throw java.io.IOException(
    "Gagal decode: ${bitmapOptions.outWidth}x" +
        "${bitmapOptions.outHeight}; " +
        "ukuran=${bytes.size} byte"
)

                runOnUiThread {
                    if (!isFinishing &&
                        generation == searchGeneration &&
                        image.isAttachedToWindow
                    ) {
                        image.setImageBitmap(bitmap)
                    }
                }
            } catch (e: Exception) {
                val message =
                    "${video.source} | ${errorDescription(e)}" +
                    "\nGambar: ${video.thumbnail}" +
                    "\nVideo: ${video.url}"

                recordThumbnailError(message)

                android.util.Log.e(
                    TAG,
                    "Thumbnail gagal: $message",
                    e
                )
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun recordThumbnailError(message: String) {
        thumbnailErrors.add(message)
        android.util.Log.e(TAG, message)

        runOnUiThread {
            if (!isFinishing) {
                statusText.text =
                    "Thumbnail bermasalah: ${thumbnailErrors.size}\n" +
                    "Tekan tombol Lihat Error Thumbnail untuk detail."
            }
        }
    }

    private fun showThumbnailErrors() {
        val errors = synchronized(thumbnailErrors) {
            thumbnailErrors.toList()
        }

        val message = if (errors.isEmpty()) {
            "Belum ada error thumbnail tercatat.\n" +
                "Lakukan pencarian terlebih dahulu."
        } else {
            errors.takeLast(15).joinToString("\n\n")
        }

        AlertDialog.Builder(this)
            .setTitle("Diagnosis Thumbnail")
            .setMessage(message)
            .setPositiveButton("Tutup", null)
            .setNeutralButton("Salin Error") { _, _ ->
                val clipboard = getSystemService(
                    CLIPBOARD_SERVICE
                ) as android.content.ClipboardManager

                clipboard.setPrimaryClip(
                    android.content.ClipData.newPlainText(
                        "VideoFinder errors",
                        message
                    )
                )

                Toast.makeText(
                    this,
                    "Error disalin",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun resolveUrl(site: String, link: String): String? {
        if (link.isBlank()) return null

        val full = try {
            URL(URL(siteOrigin(site) + "/"), decodeEntities(link))
                .toString()
        } catch (_: Exception) {
            return null
        }

        val parsed = try {
            URL(full)
        } catch (_: Exception) {
            return null
        }

        val host = parsed.host.lowercase()

        val allowed = when (site) {
            "xHamster" ->
                host == "xhamster.com" || host.endsWith(".xhamster.com")
            "MyLust" ->
                host == "mylust.com" || host.endsWith(".mylust.com")
            "PornoXO" ->
                host == "pornoxo.com" || host.endsWith(".pornoxo.com")
            else ->
                host == "eporner.com" || host.endsWith(".eporner.com")
        }

        return if (allowed && parsed.protocol == "https") full else null
    }

    private fun extractAttribute(
        text: String,
        name: String
    ): String {
        val regex = Regex(
            """\b${Regex.escape(name)}\s*=\s*["']([^"']*)["']""",
            RegexOption.IGNORE_CASE
        )

        return regex.find(text)?.groupValues?.get(1)
            ?.let { decodeEntities(it.trim()) } ?: ""
    }

    private fun cleanText(value: String): String {
        return decodeEntities(value)
            .replace(Regex("""<[^>]*>"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun decodeEntities(value: String): String {
        return value
            .replace("&amp;", "&", true)
            .replace("&quot;", "\"", true)
            .replace("&#39;", "'", true)
            .replace("&apos;", "'", true)
            .replace("&lt;", "<", true)
            .replace("&gt;", ">", true)
            .replace("&nbsp;", " ", true)
            .replace("&#x2F;", "/", true)
            .replace("&#47;", "/", true)
    }

    private fun errorDescription(e: Exception): String {
        return "${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
    }

    private fun urlEncode(value: String): String =
        URLEncoder.encode(value, "UTF-8")

    private fun pathEncode(value: String): String =
        urlEncode(value).replace("+", "%20")

    private fun updatePagination() {
        if (!::paginationBox.isInitialized) return

        paginationBox.removeAllViews()
        if (currentQuery.isBlank()) return

        if (currentPage > 1) {
            addPageButton("‹") {
                loadPage(currentPage - 1)
            }
        }

        val firstPage = maxOf(1, currentPage - 2)
        val lastPage = currentPage + 3

        for (page in firstPage..lastPage) {
            addPageButton(page.toString(), page == currentPage) {
                loadPage(page)
            }
        }

        addPageButton("›") {
            loadPage(currentPage + 1)
        }
    }

    private fun addPageButton(
        label: String,
        selected: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            minWidth = dp(42)
            setPadding(dp(4), 0, dp(4), 0)
            setTextColor(if (selected) Color.WHITE else Color.LTGRAY)
            setBackgroundColor(
                if (selected) Color.rgb(35, 110, 210)
                else Color.rgb(40, 46, 58)
            )
            isEnabled = !isLoading
            setOnClickListener { action() }
        }

        val params = LinearLayout.LayoutParams(dp(48), dp(44))
        params.setMargins(dp(2), 0, dp(2), 0)
        paginationBox.addView(button, params)
    }

    private fun addVideoResult(video: VideoResult) {
        val generation = searchGeneration

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(29, 34, 43))
        }

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.DKGRAY)
            contentDescription = "Thumbnail: ${video.title}"
        }

        card.addView(image, LinearLayout.LayoutParams(dp(120), dp(82)))

        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }

        val videoTitle = TextView(this).apply {
            text = video.title
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        textColumn.addView(videoTitle)

        val source = TextView(this).apply {
            text = "Sumber: ${video.source}"
            textSize = 12f
            setTextColor(Color.rgb(160, 190, 220))
            setPadding(0, dp(6), 0, 0)
        }
        textColumn.addView(source)

        val duration = TextView(this).apply {
            text = video.duration
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        textColumn.addView(duration)

        card.addView(
            textColumn,
            LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        )

        card.setOnClickListener {
            try {
                startActivity(
                    android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        Uri.parse(video.url)
                    )
                )
            } catch (_: Exception) {
                Toast.makeText(
                    this,
                    "Tidak bisa membuka tautan.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(8)
        resultsBox.addView(card, params)

        loadThumbnail(video, image, generation)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        imageExecutor.shutdownNow()
        super.onDestroy()
    }
}
