
package com.example.videofinder

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var queryInput: EditText
    private lateinit var adultCheck: CheckBox
    private lateinit var resultsBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var searchButton: Button
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showAgeNotice()
    }

    private fun showAgeNotice() {
        AlertDialog.Builder(this)
            .setTitle("VideoFinder")
            .setMessage("Khusus pengguna berusia 18 tahun ke atas. Hasil berasal dari Eporner.")
            .setCancelable(false)
            .setPositiveButton("Saya berusia 18+ dan lanjut") { _, _ -> buildUi() }
            .setNegativeButton("Keluar") { _, _ -> finish() }
            .show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            setBackgroundColor(Color.rgb(16, 19, 25))
        }

        val title = TextView(this).apply {
            text = "VideoFinder"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Cari video dari berbagai situs"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        queryInput = EditText(this).apply {
            hint = "Masukkan kata kunci"
            setSingleLine(true)
            setTextSize(16f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(queryInput, matchWrap())

        adultCheck = CheckBox(this).apply {
            text = "Saya berusia 18 tahun atau lebih"
            setTextColor(Color.WHITE)
            isChecked = false
        }
        root.addView(adultCheck)

        searchButton = Button(this).apply {
            text = "Cari Video"
            isAllCaps = false
            setOnClickListener { searchVideos() }
        }
        root.addView(searchButton, matchWrap())

        statusText = TextView(this).apply {
            text = "Masukkan kata kunci untuk mencari."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultsBox)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun searchVideos() {
        if (!adultCheck.isChecked) {
            Toast.makeText(this, "Konfirmasi usia 18+ dulu.", Toast.LENGTH_SHORT).show()
            return
        }

        val query = queryInput.text.toString().trim()
        if (query.isBlank()) {
            queryInput.error = "Masukkan kata kunci"
            return
        }

        searchButton.isEnabled = false
        resultsBox.removeAllViews()
        statusText.text = "Sedang mencari..."
        val encoded = URLEncoder.encode(query, "UTF-8")
        val apiUrl = "https://www.eporner.com/api/v2/video/search/" +
            "?query=$encoded&per_page=20&page=1&thumbsize=big&format=json"

        executor.execute {
            try {
                val connection = URL(apiUrl).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 15000
                connection.readTimeout = 20000
                connection.setRequestProperty("Accept", "application/json")
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()

                val json = JSONObject(response)
                val videos = json.optJSONArray("videos")
                runOnUiThread {
                    searchButton.isEnabled = true
                    resultsBox.removeAllViews()
                    if (videos == null || videos.length() == 0) {
                        statusText.text = "Tidak ada hasil untuk kata kunci ini."
                        return@runOnUiThread
                    }
                    statusText.text = "Hasil Eporner: ${videos.length()} video"
                    for (i in 0 until videos.length()) {
                        addVideoResult(videos.getJSONObject(i))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    searchButton.isEnabled = true
                    statusText.text = "Pencarian gagal. Periksa internet lalu coba lagi."
                    Toast.makeText(
                        this@MainActivity,
                        "Gagal mengambil hasil: ${e.localizedMessage ?: "koneksi bermasalah"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun addVideoResult(video: JSONObject) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(29, 34, 43))
        }

        val thumbUrl = video.optJSONObject("default_thumb")?.optString("src", "") ?: ""
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.DKGRAY)
        }
        card.addView(image, LinearLayout.LayoutParams(dp(120), dp(82)))

        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        val videoTitle = TextView(this).apply {
            text = video.optString("title", "Video tanpa judul")
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        textColumn.addView(videoTitle)

        val source = TextView(this).apply {
            text = "Sumber: Eporner"
            textSize = 12f
            setTextColor(Color.rgb(160, 190, 220))
            setPadding(0, dp(6), 0, 0)
        }
        textColumn.addView(source)

        val duration = TextView(this).apply {
            text = video.optString("length_min", "")
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        textColumn.addView(duration)

        card.addView(textColumn, LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        ))

        val videoUrl = video.optString("url", "")
        card.setOnClickListener {
            if (videoUrl.startsWith("https://www.eporner.com/")) {
                try {
                    startActivity(android.content.Intent(
                        android.content.Intent.ACTION_VIEW, Uri.parse(videoUrl)
                    ))
                } catch (_: Exception) {
                    Toast.makeText(this, "Tidak bisa membuka tautan.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(8)
        resultsBox.addView(card, params)

        if (thumbUrl.startsWith("https://")) {
            executor.execute {
                try {
                    val bitmap = URL(thumbUrl).openStream().use {
                        BitmapFactory.decodeStream(it)
                    }
                    if (bitmap != null) {
                        runOnUiThread { image.setImageBitmap(bitmap) }
                    }
                } catch (_: Exception) {
                    // Thumbnail gagal dimuat; hasil teks tetap tersedia.
                }
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
