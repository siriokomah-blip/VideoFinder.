
package com.example.videofinder

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val APP_PASSWORD = "r0y5@t@n1c"
        private const val RESULTS_PER_PAGE = 20
    }

    data class VideoResult(
        val title: String,
        val url: String,
        val thumbnail: String,
        val duration: String,
        val source: String
    )

    private lateinit var queryInput: EditText
    private lateinit var resultsBox: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var searchButton: Button
    private lateinit var paginationBox: LinearLayout

    private val executor = Executors.newSingleThreadExecutor()
    private val imageExecutor = Executors.newFixedThreadPool(3)

    private var currentQuery = ""
    private var currentPage = 1
    private var isLoading = false
    private var searchGeneration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPasswordScreen()
    }

    private fun showPasswordScreen() {
        val passwordInput = EditText(this).apply {
            hint = "Masukkan password"
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("VideoFinder")
            .setMessage("Masukkan password untuk melanjutkan")
            .setView(passwordInput)
            .setPositiveButton("Masuk", null)
            .setNegativeButton("Keluar") { _, _ -> finish() }
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener {
                    if (passwordInput.text.toString() == APP_PASSWORD) {
                        dialog.dismiss()
                        buildUi()
                    } else {
                        passwordInput.text.clear()
                        passwordInput.error = "Password salah"
                    }
                }
        }

        dialog.show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            setBackgroundColor(Color.rgb(16, 19, 25))
        }

        val title = TextView(this).apply {
            text = "VideoFinder"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Cari video dari 4 situs"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle)

        queryInput = EditText(this).apply {
            hint = "Masukkan kata kunci"
            setSingleLine(true)
            setTextSize(16f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(queryInput, matchWrap())

        searchButton = Button(this).apply {
            text = "Cari Video"
            isAllCaps = false
            setOnClickListener { searchVideos() }
        }
        root.addView(searchButton, matchWrap())

        statusText = TextView(this).apply {
            text = "Masukkan kata kunci untuk mencari."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultsBox)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        )

        val paginationScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }

        paginationBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }

        paginationScroll.addView(paginationBox)
        root.addView(paginationScroll, matchWrap())

        setContentView(root)
    }

    private fun searchVideos() {
        val query = queryInput.text.toString().trim()

        if (query.isBlank()) {
            queryInput.error = "Masukkan kata kunci"
            return
        }

        currentQuery = query
        currentPage = 1
        searchGeneration++
        loadPage(1)
    }

    private fun loadPage(page: Int) {
        if (isLoading || page < 1 || currentQuery.isBlank()) return

        isLoading = true
        val generation = searchGeneration
        val query = currentQuery

        searchButton.isEnabled = false
        resultsBox.removeAllViews()
        statusText.text = "Mencari di 4 situs, halaman $page..."
        updatePagination()

        executor.execute {
            val allResults = mutableListOf<VideoResult>()
            val errors = mutableListOf<String>()

            // Eporner: API JSON resmi.
            try {
                allResults.addAll(searchEporner(query, page))
            } catch (_: Exception) {
                errors.add("Eporner")
            }

            // Situs lainnya: mengambil dan membaca HTML pencarian.
            try {
                allResults.addAll(searchHtmlSite(
                    "xHamster",
                    "https://xhamster.com/search/" +
                        pathEncode(query) + "?page=$page",
                    query
                ))
            } catch (_: Exception) {
                errors.add("xHamster")
            }

            try {
                allResults.addAll(searchHtmlSite(
                    "XNXX",
                    "https://www.xnxx.com/search/" +
                        pathEncode(query) + "/$page",
                    query
                ))
            } catch (e: Exception) {
                errors.add(
                    "XNXX: ${e.message ?: e.javaClass.simpleName}"
                )
            }

            try {
                allResults.addAll(searchHtmlSite(
                    "XVideos",
                    "https://www.xvideos.com/" +
                        "?k=${urlEncode(query)}&p=${page - 1}",
                    query
                ))
            } catch (_: Exception) {
                errors.add("XVideos")
            }

            runOnUiThread {
                if (isFinishing || generation != searchGeneration) {
                    if (generation == searchGeneration) {
                        isLoading = false
                        searchButton.isEnabled = true
                    }
                    return@runOnUiThread
                }

                resultsBox.removeAllViews()
                currentPage = page

                if (allResults.isEmpty()) {
                    statusText.text = if (errors.size == 4) {
                        "Semua sumber gagal diakses. Periksa internet atau proteksi situs."
                    } else {
                        "Tidak ada hasil yang berhasil dibaca. Coba kata kunci lain."
                    }
                } else {
                    statusText.text =
                        "Halaman $page • ${allResults.size} hasil" +
                        if (errors.isNotEmpty()) {
                            "\nSumber gagal diakses: ${errors.joinToString()}"
                        } else {
                            ""
                        }

                    allResults.forEach { addVideoResult(it) }
                }

                updatePagination()
                isLoading = false
                searchButton.isEnabled = true
                updatePagination()
            }
        }
    }

    private fun searchEporner(
        query: String,
        page: Int
    ): List<VideoResult> {
        val apiUrl =
            "https://www.eporner.com/api/v2/video/search/" +
            "?query=${urlEncode(query)}" +
            "&per_page=$RESULTS_PER_PAGE" +
            "&page=$page&thumbsize=big&format=json"

        val json = JSONObject(fetchText(apiUrl))
        val videos = json.optJSONArray("videos")
            ?: return emptyList()

        val results = mutableListOf<VideoResult>()

        for (i in 0 until videos.length()) {
            val video = videos.optJSONObject(i) ?: continue
            val videoUrl = video.optString("url", "")
            if (!videoUrl.startsWith("https://www.eporner.com/")) continue

            val thumb = video.optJSONObject("default_thumb")
                ?.optString("src", "") ?: ""

            results.add(
                VideoResult(
                    title = cleanText(video.optString("title", "Video tanpa judul")),
                    url = videoUrl,
                    thumbnail = thumb,
                    duration = video.optString("length_min", ""),
                    source = "Eporner"
                )
            )
        }

        return results
    }

    private fun searchHtmlSite(
        site: String,
        searchUrl: String,
        query: String
    ): List<VideoResult> {
        val html = fetchText(searchUrl)
        return parseVideoHtml(site, html, query)
    }

    
    private fun parseVideoHtml(
        site: String,
        html: String,
        query: String
    ): List<VideoResult> {
        val results = mutableListOf<VideoResult>()
        val seen = mutableSetOf<String>()

        val videoPathRegex = when (site) {
            "xHamster" -> Regex(
                """/videos/[^"'?#\s<>]+""",
                RegexOption.IGNORE_CASE
            )
            "XNXX" -> Regex(
                """/video-[^"'?#\s<>]+""",
                RegexOption.IGNORE_CASE
            )
            else -> Regex(
                """/video\.[^"'?#\s<>]+""",
                RegexOption.IGNORE_CASE
            )
        }

        val anchorRegex = Regex(
            """<a\b([^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*)>(.*?)</a\s*>""",
            setOf(
                RegexOption.IGNORE_CASE,
                RegexOption.DOT_MATCHES_ALL
            )
        )

        val imgRegex = Regex(
            """<(?:img|source)\b[^>]*>""",
            setOf(
                RegexOption.IGNORE_CASE,
                RegexOption.DOT_MATCHES_ALL
            )
        )

        for (match in anchorRegex.findAll(html)) {
            if (results.size >= RESULTS_PER_PAGE) break

            val attrs = match.groupValues[1]
            val href = decodeEntities(match.groupValues[2])
            val inner = match.groupValues[3]

            if (!videoPathRegex.containsMatchIn(href)) continue

            val videoUrl = resolveUrl(site, href) ?: continue
            if (!seen.add(videoUrl)) continue

            val titleFromLink = extractAttribute(attrs, "title")
            val titleFromAria = extractAttribute(attrs, "aria-label")
            val titleFromImage = Regex(
                """<img\b[^>]*>""",
                setOf(
                    RegexOption.IGNORE_CASE,
                    RegexOption.DOT_MATCHES_ALL
                )
            ).find(inner)?.value?.let {
                extractAttribute(it, "alt")
            } ?: ""

            val title = listOf(
                titleFromLink,
                titleFromAria,
                titleFromImage
            )
                .map { cleanText(it) }
                .firstOrNull {
                    it.length >= 3 &&
                        !it.matches(Regex("""[\d\s.:xX-]+""")) &&
                        !it.matches(Regex("""\d+\s*dp""", RegexOption.IGNORE_CASE))
                } ?: ""

            if (title.isBlank()) continue

            var thumbnail = ""

            for (imageMatch in imgRegex.findAll(inner)) {
                val tag = imageMatch.value

                val candidates = listOf(
                    "data-src",
                    "data-original",
                    "data-lazy-src",
                    "data-thumb",
                    "data-thumbnail",
                    "data-srcset",
                    "src",
                    "srcset"
                )

                thumbnail = candidates
                    .asSequence()
                    .map { extractAttribute(tag, it) }
                    .map {
                        it.substringBefore(",")
                            .trim()
                            .substringBefore(" ")
                    }
                    .firstOrNull {
                        it.startsWith("https://") ||
                            it.startsWith("http://") ||
                            it.startsWith("//") ||
                            it.startsWith("/")
                    } ?: ""

                if (thumbnail.isNotBlank()) break
            }

            if (thumbnail.isBlank()) {
                thumbnail = listOf(
                    "data-thumb",
                    "data-thumbnail",
                    "data-preview",
                    "data-image"
                ).asSequence()
                    .map { extractAttribute(attrs, it) }
                    .firstOrNull { it.isNotBlank() }
                    ?: ""
            }

            if (thumbnail.startsWith("//")) {
                thumbnail = "https:$thumbnail"
            } else if (thumbnail.startsWith("/")) {
                val origin = when (site) {
                    "xHamster" -> "https://xhamster.com"
                    "XNXX" -> "https://www.xnxx.com"
                    else -> "https://www.xvideos.com"
                }
                thumbnail = origin + thumbnail
            }

            if (!thumbnail.startsWith("https://")) {
                thumbnail = ""
            }

            val duration = Regex(
                """\b\d{1,2}:\d{2}(?::\d{2})?\b"""
            ).find(inner)?.value ?: ""

            results.add(
                VideoResult(
                    title = cleanText(title),
                    url = videoUrl,
                    thumbnail = thumbnail,
                    duration = duration,
                    source = site
                )
            )
        }

        return results
    }

    private fun fetchText(address: String): String {
        var connection: HttpURLConnection? = null

        try {
            connection = URL(address).openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            connection.setRequestProperty(
                "Accept",
                "text/html,application/json,*/*"
            )
            connection.setRequestProperty(
                "Accept-Language", "en-US,en;q=0.9"
            )

            val code = connection.responseCode
            val stream = if (code in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            } ?: throw Exception("HTTP $code")

            val body = stream.bufferedReader(Charsets.UTF_8).use {
                it.readText()
            }

            if (code !in 200..299) throw Exception("HTTP $code")
            return body
        } finally {
            connection?.disconnect()
        }
    }

    private fun resolveUrl(site: String, link: String): String? {
        if (link.isBlank()) return null

        val base = when (site) {
            "xHamster" -> "https://xhamster.com/"
            "XNXX" -> "https://www.xnxx.com/"
            "XVideos" -> "https://www.xvideos.com/"
            else -> "https://www.eporner.com/"
        }

        val full = try {
            URL(URL(base), decodeEntities(link)).toString()
        } catch (_: Exception) {
            return null
        }

        val allowed = when (site) {
            "xHamster" -> full.startsWith("https://xhamster.com/")
            "XNXX" -> full.startsWith("https://www.xnxx.com/")
            "XVideos" -> full.startsWith("https://www.xvideos.com/")
            else -> full.startsWith("https://www.eporner.com/")
        }

        return if (allowed) full else null
    }

    private fun extractAttribute(
        text: String,
        name: String
    ): String {
        val regex = Regex(
            """\b${Regex.escape(name)}\s*=\s*["']([^"']*)["']""",
            RegexOption.IGNORE_CASE
        )
        return regex.find(text)?.groupValues?.get(1)
            ?.let { decodeEntities(it.trim()) } ?: ""
    }

    private fun cleanText(value: String): String {
        return decodeEntities(value)
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun decodeEntities(value: String): String {
        return value
            .replace("&amp;", "&", true)
            .replace("&quot;", "\"", true)
            .replace("&#39;", "'", true)
            .replace("&apos;", "'", true)
            .replace("&lt;", "<", true)
            .replace("&gt;", ">", true)
            .replace("&nbsp;", " ", true)
            .replace("&#x2F;", "/", true)
    }

    private fun urlEncode(value: String): String =
        URLEncoder.encode(value, "UTF-8")

    private fun pathEncode(value: String): String =
        urlEncode(value).replace("+", "%20")

    private fun updatePagination() {
        if (!::paginationBox.isInitialized) return

        paginationBox.removeAllViews()
        if (currentQuery.isBlank()) return

        if (currentPage > 1) {
            addPageButton("‹") {
                loadPage(currentPage - 1)
            }
        }

        val firstPage = maxOf(1, currentPage - 2)
        val lastPage = currentPage + 3

        for (page in firstPage..lastPage) {
            addPageButton(page.toString(), page == currentPage) {
                loadPage(page)
            }
        }

        addPageButton("›") {
            loadPage(currentPage + 1)
        }
    }

    private fun addPageButton(
        label: String,
        selected: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            minWidth = dp(42)
            setPadding(dp(4), 0, dp(4), 0)
            setTextColor(if (selected) Color.WHITE else Color.LTGRAY)
            setBackgroundColor(
                if (selected) Color.rgb(35, 110, 210)
                else Color.rgb(40, 46, 58)
            )
            isEnabled = !isLoading
            setOnClickListener { action() }
        }

        val params = LinearLayout.LayoutParams(dp(48), dp(44))
        params.setMargins(dp(2), 0, dp(2), 0)
        paginationBox.addView(button, params)
    }

    private fun addVideoResult(video: VideoResult) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(29, 34, 43))
        }

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.DKGRAY)
        }

        card.addView(image, LinearLayout.LayoutParams(dp(120), dp(82)))

        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }

        val videoTitle = TextView(this).apply {
            text = video.title
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        }
        textColumn.addView(videoTitle)

        val source = TextView(this).apply {
            text = "Sumber: ${video.source}"
            textSize = 12f
            setTextColor(Color.rgb(160, 190, 220))
            setPadding(0, dp(6), 0, 0)
        }
        textColumn.addView(source)

        val duration = TextView(this).apply {
            text = video.duration
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        textColumn.addView(duration)

        card.addView(
            textColumn,
            LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        )

        card.setOnClickListener {
            try {
                startActivity(
                    android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        Uri.parse(video.url)
                    )
                )
            } catch (_: Exception) {
                Toast.makeText(
                    this, "Tidak bisa membuka tautan.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(8)
        resultsBox.addView(card, params)

        if (video.thumbnail.startsWith("https://")) {
            imageExecutor.execute {
                try {
                    val bitmap = URL(video.thumbnail).openStream().use {
                        BitmapFactory.decodeStream(it)
                    }

                    if (bitmap != null) {
                        runOnUiThread {
                            if (!isFinishing) image.setImageBitmap(bitmap)
                        }
                    }
                } catch (_: Exception) {
                    // Thumbnail tidak tersedia.
                }
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        imageExecutor.shutdownNow()
        super.onDestroy()
    }
}
