package com.example.videofinder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : Activity() {
    private lateinit var queryInput: EditText
    private lateinit var adultCheck: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showAgeNotice()
    }

    private fun showAgeNotice() {
        AlertDialog.Builder(this)
            .setTitle("VideoFinder — prototipe")
            .setMessage("Aplikasi ini hanya untuk orang dewasa (18+). Aplikasi hanya meneruskan kata kunci ke mesin pencari web; hasil dan aturan akses ditentukan oleh penyedia pencarian dan situs tujuan.")
            .setCancelable(false)
            .setPositiveButton("Saya berusia 18+ dan lanjut") { _, _ -> buildUi() }
            .setNegativeButton("Keluar") { _, _ -> finish() }
            .show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            setBackgroundColor(Color.rgb(16, 19, 25))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
        }

        val title = TextView(this).apply {
            text = "VideoFinder"
            textSize = 30f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "Cari dengan kata kunci di beberapa mesin pencari web"
            textSize = 14f
            setTextColor(Color.rgb(190, 198, 210))
            setPadding(0, dp(6), 0, dp(18))
        }
        content.addView(subtitle)

        queryInput = EditText(this).apply {
            setSingleLine(true)
            setText("swap wife")
            hint = "Masukkan kata kunci"
            textSize = 16f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        content.addView(queryInput, matchWrap())

        adultCheck = CheckBox(this).apply {
            text = "Saya berusia 18 tahun atau lebih"
            setTextColor(Color.WHITE)
            isChecked = false
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(adultCheck)

        addSearchButton(content, "Cari di Bing", "https://www.bing.com/search?q=")
        addSearchButton(content, "Cari di DuckDuckGo", "https://duckduckgo.com/?q=")
        addSearchButton(content, "Cari di Google", "https://www.google.com/search?q=")

        val note = TextView(this).apply {
            text = "Catatan: ini prototipe pencarian, bukan indeks video mandiri. Mesin pencari dapat membatasi atau menyaring hasil dewasa. VideoFinder tidak mengunduh, meng-host, atau memverifikasi konten dan tidak bergantung pada PornMD."
            textSize = 13f
            setTextColor(Color.rgb(190, 198, 210))
            setPadding(0, dp(18), 0, dp(10))
        }
        content.addView(note)

        val privacy = TextView(this).apply {
            text = "Privasi: kata kunci dikirim ke mesin pencari yang dipilih saat tombol ditekan."
            textSize = 12f
            setTextColor(Color.rgb(150, 160, 175))
        }
        content.addView(privacy)

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
    }

    private fun addSearchButton(parent: LinearLayout, label: String, baseUrl: String) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setOnClickListener {
                if (!adultCheck.isChecked) {
                    Toast.makeText(this@MainActivity, "Centang konfirmasi usia 18+ dulu.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val query = queryInput.text.toString().trim()
                if (query.isBlank()) {
                    Toast.makeText(this@MainActivity, "Masukkan kata kunci dulu.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
                val uri = Uri.parse(baseUrl + encoded)
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Tidak ada browser yang bisa membuka pencarian.", Toast.LENGTH_LONG).show()
                }
            }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = dp(8)
        parent.addView(button, params)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
